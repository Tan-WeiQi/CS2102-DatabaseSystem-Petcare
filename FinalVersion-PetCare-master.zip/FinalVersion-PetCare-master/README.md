# FinalVersion-PetCare
Install Xampp with apache and MySQL.
Initialise tables with init.sql and you're good to go. 

School project. 
