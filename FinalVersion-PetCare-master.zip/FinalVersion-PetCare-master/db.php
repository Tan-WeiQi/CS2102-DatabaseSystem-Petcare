<?php 

$con = mysqli_connect('localhost', "root", "", "petcare");

if (!$con){ 
	die("you noob shit, connection failed");
#die means to terminate when the left side cant work
}
?>